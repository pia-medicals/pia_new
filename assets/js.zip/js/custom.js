    function chartthediv(div = 'mychart', labels, jsondataset, type,yaxis,xaxis='Month'){
    var ctx = document.getElementById(div);
    var lastsixmonth = new Chart(ctx, {
        type: type,
        data: {
            labels: labels,
            datasets: jsondataset
        },

        options: {           
            scales: {
                xAxes: [{
                    display: true,
                    scaleLabel: {
                        display: true,
                        labelString: xaxis
                    }
                }],
                yAxes: [{
                    display: true,
                    scaleLabel: {
                        display: true,
                        labelString: yaxis
                    },
                    ticks: {
                        beginAtZero:true
                    }
                }]
            }
        }
    });
    }



function excel_btn(e) {
    var result = [];
    var carry = [];
    var sub = [];
    var billing = [];
    $('table#carry_table tbody tr').each(function(i,obj){
        var dmmy = [];
        $(obj).find('td').each(function(j,td){
            dmmy[j] = $(td).text();
        });
        carry[i] = dmmy;
    });
    $('table#sub_table tbody tr').each(function(i,obj){
        var dmmy = [];
        $(obj).find('td').each(function(j,td){
            dmmy[j] = $(td).text();
        });
        sub[i] = dmmy;
    });
    $('table#billing_table tbody tr').each(function(i,obj){
        var dmmy = [];
        $(obj).find('td').each(function(j,td){
            dmmy[j] = $(td).text();
        });
        billing[i] = dmmy;
    });
    result['carry'] = carry;
    result['sub'] = sub;
    result['billing'] = billing;
    var t_bfr_disc = $('td#t_bfr_disc strong').text();
    var pers = $('td#t_amt_aftr span').text();
    var disc = $('td#disc strong').text();
    var t_amt_aftr = $('td#t_amt_aftr strong').text();
    var sub_amount = $('td#sub_a  strong').text();
    var main_fee_amt = $('td#main_fee_amt  span').text();
    var main_fee_type = $('td#main_fee_type  span').text();
    var gtotal = $('td#gtotal  strong').text();






    $('input[name="carry"]').val(JSON.stringify(carry));
    $('input[name="sub"]').val(JSON.stringify(sub));
    $('input[name="billing"]').val(JSON.stringify(billing));
    $('input[name="t_bef_disc"]').val(JSON.stringify(t_bfr_disc));
    $('input[name="pers"]').val(JSON.stringify(pers));
    $('input[name="disc"]').val(JSON.stringify(disc));
    $('input[name="t_amt_aftr"]').val(JSON.stringify(t_amt_aftr));
    $('input[name="sub_amount"]').val(JSON.stringify(sub_amount));
    $('input[name="main_fee_amt"]').val(JSON.stringify(main_fee_amt));
    $('input[name="main_fee_type"]').val(JSON.stringify(main_fee_type));
    $('input[name="gtotal"]').val(JSON.stringify(gtotal));


   $(e).parent().submit();
}









	jQuery(document).ready(function($) {
		jQuery('.input100').focusout(function(){

			if($(this).val() != "")
				$(this).next('span').attr('data-placeholder','');
			else
			{
				if($(this).attr('name') == 'user')
				$(this).next('span').attr('data-placeholder','Username');
				else
				$(this).next('span').attr('data-placeholder','Password');
			}

		});

		   $('.button-left').click(function(){
		       $('.sidebar').toggleClass('fliph');
		       $('.dashboard_body').toggleClass('fliph');
		       $('.black_bg').toggleClass('fliph');
		   });
		   if ($(window).width() < 993) {
			    $('.sidebar').addClass('fliph');
		       $('.dashboard_body').addClass('fliph');
		       $('.black_bg').addClass('fliph');
			}

jQuery('a.delete_link').click(
        function(e) {
            e.preventDefault();
            var url = $(this).attr('href');
            $('#delete_modal .delete_url').attr('href',url); 
            $('#delete_modal').modal('show'); 
            //if (confirm("Are you sure to delete this entry ?")) window.location = jQuery(this).attr('href');
        }
    );

$('label.file-upload').click(function(){
	$(this).find('input').click();
});

/*admin repeted fields*/
/*var next = 0;
    $("#add-more").click(function(e){
        e.preventDefault();
        var addto = "#field" + next;
        var addRemove = "#field" + (next);
        next = next + 1;
        var newIn = ' <div id="field'+ next +'" name="field'+ next +'">';
        newIn = newIn+jQuery('#field').first().html()+'</div>';



        var newInput = $(newIn);
        var removeBtn = '<button id="remove' + (next - 1) + '" class="btn btn-danger remove-me" >Remove</button></div></div><div id="field">';
        var removeButton = $(removeBtn);
        $(addto).after(newInput);
        $(addRemove).after(removeButton);
        $("#field" + next).attr('data-source',$(addto).attr('data-source'));
        $("#count").val(next);  
        
            $('.remove-me').click(function(e){
                e.preventDefault();
                var fieldNum = this.id.charAt(this.id.length-1);
                var fieldID = "#field" + fieldNum;
                $(this).remove();
                $(fieldID).remove();
            });
    });*/
/*admin repeted fields*/

/*$('.main.side .sidebar').css({
	height: $(window).height() ,
});
*/



function active_side(){
	
	var url      = window.location.href;
	var res = url.split("/");
	res = res[res.length-1];
	res = res.split("?");
	res = res[0];
	res = res.split("#");
	res = res[0];
	//$("a[href$="+res+"]").addClass('act');
	$('.main.side .sidebar').find('[data-active="' + res + '"]').addClass('act');
	//var element_ul = $("a[href$="+res+"]").parents('ul.sub-menu');
	var element_ul = $('.main.side .sidebar').find('[data-active="' + res + '"]').parents('ul.sub-menu');
	jQuery(element_ul).addClass('in').css('height','auto');
	jQuery(element_ul).prev('a.collapsed').addClass('open');

}
active_side();



$('#analyses_performed').multiselect();


$('.form-group.analyses_select input').change(function(){
    var id = jQuery(this).val();
    var title = jQuery(this).parent().attr('title');
    if(jQuery(this).is(":checked")){
        var html = ' <div class="each each_'+id+'"> <label for="addon_flows_'+id+'">Addon flows for '+title+'</label> <input type="number" data-rule-required="true" min="1" id="addon_flows_'+id+'" class="form-control" required name="addon_flows_'+id+'"> </div>';
        if(jQuery('.each_'+id).length == 0)
        jQuery('.multiple_inputs').append(html);
    }else{
        jQuery('.each_'+id).remove();
    }



});

var html = $('.pdf_div').html();
$('input[name="pdf"]').val(html);

	});



function activeTab(tab){
    $('.nav-tabs a[href="' + tab + '"]').tab('show');
};




function printData(divId)
{
   var content = document.getElementById(divId).innerHTML;
    var mywindow = window.open('', 'Print', 'height=600,width=800');

    mywindow.document.write('<html><head><title>Print</title>');
    mywindow.document.write('<style>table{border-collapse:collapse;border-spacing:0}td,th{padding:0}@media print{*{text-shadow:none!important;color:#000!important;background:transparent!important;box-shadow:none!important}thead{display:table-header-group}tr{page-break-inside:avoid}}*{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}:before,:after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}table{max-width:100%;background-color:transparent}th{text-align:left}table.admin{border:1px solid #ccc;width:100%;margin:0;padding:0;border-collapse:collapse;border-spacing:0;background:#eeefe8;-webkit-box-shadow:7px 22px 40px -1px rgba(0,0,0,0.15);-moz-box-shadow:7px 22px 40px -1px rgba(0,0,0,0.15);box-shadow:7px 22px 40px -1px rgba(0,0,0,0.15)}table.admin thead{background:#025b6c;color:#fff}table.admin tr{border:1px solid #000;padding:5px}table.admin th,table.admin td{padding:10px;text-align:center}table.admin th{text-transform:uppercase;font-size:14px;letter-spacing:1px}@media screen and (max-width:600px){table.admin{border:0}table.admin thead{display:none}table.admin tr{margin-bottom:10px;display:block;border-bottom:2px solid #000}table.admin td{display:block;text-align:right;font-size:13px;border-bottom:1px solid #ccc}table.admin td:last-child{border-bottom:0}table.admin td:before{content:attr(data-label);float:left;text-transform:uppercase;font-weight:bold}}::-moz-selection{background:##777;color:#00a7f5}::selection{background:##777;color:#00a7f5}::-moz-selection{background:##777;color:#00a7f5}*,*:hover{outline:none!important;text-decoration:none!important}</style></head><body >');
    mywindow.document.write(content);
    mywindow.document.write('</body></html>');

    mywindow.document.close();
    mywindow.focus()
    mywindow.print();
    mywindow.close();
    return true;
}

